Cat.png: from iOS Games by Tutorials book, available at http://www.raywenderlich.com.
mouse.png: from scract.mit.edu used under the CC BY-SA 2.0 license
yarn.png: from https://pixabay.com/en/yarn-thread-twine-ball-sewing-150415/ used under the CC0 Public Domain license
