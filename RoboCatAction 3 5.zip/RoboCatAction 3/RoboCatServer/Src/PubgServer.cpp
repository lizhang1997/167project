#include <RoboCatServerPCH.h>


PubgServer::PubgServer()
{
    
}

void PubgServer::HandleDying()
{
    NetworkManagerServer::sInstance->UnregisterGameObject( this );
}


bool PubgServer::HandleCollisionWithCat( RoboCat* inCat )
{
    if( inCat->GetPlayerId() != GetPlayerId() )
    {
        SetDoesWantToDie( true );
        
        ScoreBoardManager::sInstance->IncScore( inCat->GetPlayerId(), 1 );
    }
    
    return false;
}



