#include "RoboCatClientPCH.h"


PubgClient::PubgClient()
{
    mSpriteComponent.reset( new SpriteComponent( this ) );
    mSpriteComponent->SetTexture( TextureManager::sInstance->GetTexture( std::string("pubg") ) );
}





